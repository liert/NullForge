package com.github.nullforge.Listeners;

import com.github.nullforge.Commands.OnAdminCommands;
import com.github.nullforge.Config.Settings;
import com.github.nullforge.Data.DrawData;
import com.github.nullforge.Utils.GemUtil;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class OnPlayerChat implements Listener {
    public static List<String> fList = new ArrayList<String>();
    public static List<String> detailList = new ArrayList<String>();
    public static List<String> attribList = new ArrayList<String>();
    public static Map<String, List<String>> tempDetailMap = new HashMap<String, List<String>>();
    public static Map<String, List<String>> tempAttribMap = new HashMap<String, List<String>>();

    @EventHandler
    public void chat(AsyncPlayerChatEvent e) {
        ItemStack item;
        Player p = e.getPlayer();
        if (!e.getMessage().equalsIgnoreCase("ok")) {
            if (detailList.contains(p.getName()) && OnAdminCommands.tempMap.containsKey(p.getName())) {
                e.setCancelled(true);
                String msg = e.getMessage();
                if (msg.contains("&")) {
                    msg = msg.replaceAll("&", "§");
                }
                List<String> list = new ArrayList<String>();
                list = tempDetailMap.containsKey(p.getName()) ? tempDetailMap.get(p.getName()) : new ArrayList();
                list.add(msg);
                tempDetailMap.put(p.getName(), list);
                p.sendMessage("§c[系统]§a添加介绍成功,请继续输入,输入ok完成编辑");
                return;
            }
            if (attribList.contains(p.getName()) && OnAdminCommands.tempMap.containsKey(p.getName())) {
                e.setCancelled(true);
                String msg = e.getMessage();
                if (msg.contains("&")) {
                    msg = msg.replaceAll("&", "§");
                }
                List<String> list = new ArrayList<String>();
                list = tempAttribMap.containsKey(p.getName()) ? tempAttribMap.get(p.getName()) : new ArrayList();
                list.add(msg);
                tempAttribMap.put(p.getName(), list);
                p.sendMessage("§c[系统]§a添加属性成功,请继续输入,输入ok完成编辑");
                return;
            }
        }
        if (!OnAdminCommands.tempMap.containsKey(p.getName()) || !OnAdminCommands.nameTempMap.containsKey(p.getName())) {
            return;
        }
        e.setCancelled(true);
        DrawData dd = OnAdminCommands.tempMap.get(p.getName());
        String msg2 = e.getMessage();
        if (!(msg2.equalsIgnoreCase("gem") || msg2.equalsIgnoreCase("formula") || msg2.equalsIgnoreCase("result") || msg2.contains("playerlevel") || msg2.equalsIgnoreCase("detail") || msg2.equalsIgnoreCase("attrib") || msg2.equalsIgnoreCase("ok") || msg2.equalsIgnoreCase("cancel"))) {
            p.sendMessage("§c请输入图纸的关键变量...");
            p.sendMessage("§cgem§8------------------§a手持宝石在聊天栏输入此文字可设置该图纸所需的宝石");
            p.sendMessage("§cformula§8--------------§a设置一个图纸所需的合成物品");
            p.sendMessage("§cresult§8---------------§a设置一个图纸合成成功后返回的物品");
            p.sendMessage("§cplayerlevel [等级]§8----§a设置一个图纸所需的玩家等级");
            p.sendMessage("§cdetail§8--------------§a设置一个图纸的介绍详细内容,每添加一次是一行,输ok确定");
            p.sendMessage("§cattrib§8--------------§a设置一个图纸的属性,每添加一次是一行,输ok确定");
            p.sendMessage("§cok§8-------------------§a完成一个锻造图纸的创建");
            p.sendMessage("§ccancel§8----------------§a取消图纸的创建或设置");
            return;
        }
        if (msg2.equalsIgnoreCase("gem")) {
            if (p.getItemInHand() == null) {
                p.sendMessage("§c[系统]§a请手持宝石输入此文字来设置该图纸的宝石");
                return;
            }
            item = p.getItemInHand();
            int level = GemUtil.getGemLevel(item);
            if (level == 0) {
                p.sendMessage("§c[系统]§a你手中的物品不是宝石!");
                return;
            }
            dd.setGem(item);
            dd.setNeedGemLevel(level);
            p.sendMessage("§c[系统]§a设置完成!");
        }
        if (msg2.equalsIgnoreCase("formula")) {
            List<ItemStack> list2 = dd.getFormula() == null ? new ArrayList<ItemStack>() : dd.getFormula();
            Inventory inv = Bukkit.createInventory(null, 54, "§c请放入锻造材料来完成设置...");
            for (ItemStack item2 : list2) {
                inv.addItem(item2);
            }
            fList.add(p.getName());
            p.openInventory(inv);
            p.sendMessage("§c[系统]§a请将材料放入窗口内关闭窗口完成设置");
        }
        if (msg2.equalsIgnoreCase("result")) {
            if (p.getItemInHand() == null) {
                p.sendMessage("§c[系统]§a请手持该图纸返回的最终装备来设置该图纸锻造成功的最终物品");
                return;
            }
            item = p.getItemInHand();
            dd.setResult(item);
            p.sendMessage("§c[系统]§a设置成功");
        }
        if (msg2.contains("playerlevel")) {
            if (!msg2.contains(" ")) {
                p.sendMessage("§cplayerlevel [等级]§8----§a设置一个图纸所需的玩家等级");
                return;
            }
            String[] raw = msg2.split(" ");
            if (raw.length < 2) {
                p.sendMessage("§cplayerlevel [等级]§8----§a设置一个图纸所需的玩家等级");
                return;
            }
            String rawLevel = raw[1];
            if (!this.isNum(rawLevel)) {
                p.sendMessage("§c[系统]§a等级必须为数字!");
                return;
            }
            int level2 = Integer.parseInt(rawLevel);
            if (level2 < 0 || level2 > Settings.I.Max_Player_Forge_Level) {
                p.sendMessage("§c[系统]§a图纸所需的等级不能小于零或者大于配置文件中设置的最大弯矩锻造等级");
                return;
            }
            dd.setNeedPlayerLevel(level2);
            p.sendMessage("§c[系统]§a设置成功!");
        }
        if (msg2.equalsIgnoreCase("detail")) {
            p.sendMessage("§c[系统]§a请在聊天栏输入你的图纸介绍详情,每添加一次是一行,输ok确定");
            detailList.add(p.getName());
        }
        if (msg2.equalsIgnoreCase("attrib")) {
            p.sendMessage("§c[系统]§a请在聊天栏输入你的图纸属性,每添加一次是一行,输ok确定");
            p.sendMessage("§c[系统]§a属性所有关于系统可以浮动的数值一律用(数值)(数值)来表示,这表示该数值的基础属性!");
            attribList.add(p.getName());
        }
        if (msg2.equalsIgnoreCase("ok")) {
            List<String> list3;
            if (detailList.contains(p.getName()) && tempDetailMap.containsKey(p.getName()) && tempDetailMap.get(p.getName()) != null && tempDetailMap.get(p.getName()).size() != 0) {
                detailList.remove(p.getName());
                list3 = tempDetailMap.get(p.getName());
                tempDetailMap.remove(p.getName());
                dd.setDetail(list3);
                p.sendMessage("§c[系统]§a设置介绍信息成功");
                return;
            }
            if (attribList.contains(p.getName()) && tempAttribMap.containsKey(p.getName()) && tempAttribMap.get(p.getName()) != null && tempAttribMap.get(p.getName()).size() != 0) {
                attribList.remove(p.getName());
                list3 = tempAttribMap.get(p.getName());
                tempAttribMap.remove(p.getName());
                dd.setAttrib(list3);
                p.sendMessage("§c[系统]§a设置属性信息成功");
                return;
            }
            if (dd.getGem() == null) {
                p.sendMessage("§c[系统]§a图纸所需的宝石尚未设置!");
                return;
            }
            if (dd.getFormula() == null) {
                p.sendMessage("§c[系统]§a图纸所需的合成材料尚未设置!");
                return;
            }
            if (dd.getResult() == null) {
                p.sendMessage("§c[系统]§a图纸所需的锻造成功的最终装备尚未设置!");
                return;
            }
            if (dd.getDetail() == null) {
                p.sendMessage("§c[系统]§a图纸所需的介绍尚未设置");
                return;
            }
            String name = OnAdminCommands.nameTempMap.get(p.getName());
            DrawData.DrawMap.put(name, dd);
            OnAdminCommands.nameTempMap.remove(p.getName());
            OnAdminCommands.tempMap.remove(p.getName());
            p.sendMessage("§c[系统]§a成功的完成对图纸§b" + name + "§a的内容设置!");
        }
        if (msg2.equalsIgnoreCase("cancel")) {
            OnAdminCommands.nameTempMap.remove(p.getName());
            OnAdminCommands.tempMap.remove(p.getName());
            p.sendMessage("§c[系统]§a已经取消了对该图纸的设置!");
        }
    }

    public boolean isValid(ItemStack rs) {
        int id = rs.getTypeId();
        return id == 267 || id == 268 || id == 272 || id == 276 || id == 283 || id == 298 || id == 302 || id == 306 || id == 310 || id == 314 || id == 299 || id == 303 || id == 307 || id == 311 || id == 315 || id == 300 || id == 304 || id == 308 || id == 312 || id == 316 || id == 301 || id == 305 || id == 309 || id == 313 || id == 317;
    }

    public boolean isNum(String str) {
        Pattern pattern = Pattern.compile("[0-9]*");
        Matcher isNum = pattern.matcher(str);
        return isNum.matches();
    }
}

