package com.github.nullforge.Listeners;

import java.util.List;

import com.github.nullforge.Data.DrawData;
import com.github.nullforge.Data.PlayerData;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class OnPlayerInteract
implements Listener {
    @EventHandler
    public void interact(PlayerInteractEvent e) {
        Player p = e.getPlayer();
        Action ac = e.getAction();
        if (p.getItemInHand() == null) {
            return;
        }
        if (ac != Action.RIGHT_CLICK_AIR && ac != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        ItemStack item = p.getItemInHand();
        if (OnPlayerClickInv.getDraw(item) == null) {
            return;
        }
        DrawData dd = OnPlayerClickInv.getDraw(item);
        PlayerData pd = PlayerData.pMap.get(p.getName());
        if (pd.getLevel() < dd.getNeedPlayerLevel()) {
            p.sendMessage("§c[系统]§a你的等级不足以学习该锻造图纸!");
            return;
        }
        String dName = DrawData.getDrawName(dd);
        if (dName == null) {
            p.sendMessage("§c[系统]§a该图纸已经废弃,无法使用!");
            return;
        }
        if (item.getAmount() > 1) {
            p.sendMessage("§c[系统]§a学习的图纸数量必须为1!");
            return;
        }
        List<String> learn = pd.getLearn();
        if (learn.contains(dName)) {
            p.sendMessage("§c[系统]§a你已经学会该图纸,无法再次学习");
            return;
        }
        learn.add(dName);
        pd.setLearn(learn);
        p.getInventory().removeItem(item);
        p.sendMessage("§c[系统]§a你已经成功的学习了图纸§b§l" + dName + "§a,你可以使用/dz来进行锻造该图纸的装备");
    }
}

