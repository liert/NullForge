package com.github.nullforge.Listeners;

import java.text.DecimalFormat;

import com.github.nullforge.Config.Settings;
import com.github.nullforge.Data.PlayerData;
import com.github.nullforge.Event.PlayerForgeItemEvent;
import com.github.nullforge.Main;
import com.github.nullforge.Utils.ExpUtil;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

public class OnPlayerForgeItem
implements Listener {
    @EventHandler
    public void forgeItem(PlayerForgeItemEvent e) {
        Player p = e.getPlayer();
        PlayerData pd = PlayerData.pMap.get(p.getName());
        if (pd.getLevel() >= Settings.I.Max_Player_Forge_Level) {
            p.sendMessage("§c[系统]§a你的锻造等级已经达到了最大等级!");
            return;
        }
        int gemLevel = e.getDraw().getNeedGemLevel();
        if (!Settings.I.Forge_Exp.containsKey(gemLevel)) {
            return;
        }
        int baseExp = Settings.I.Forge_Exp.get(gemLevel);
        int floatExp = Main.rd.nextInt(Settings.I.Forge_Exp_Float);
        double expFloat = (double)baseExp * ((double)floatExp / 100.0);
        double exp = Main.rd.nextBoolean() ? (double)baseExp + expFloat : (double)baseExp - expFloat;
        p.sendMessage("§c[系统]§a你获得了锻造经验§c§l" + new DecimalFormat("###.00").format(exp) + "§a点");
        double PlayerExp = pd.getExp();
        double needExp = ExpUtil.getNeedExp(p);
        if (PlayerExp + exp >= needExp) {
            pd.setLevel(pd.getLevel() + 1);
            pd.setExp(PlayerExp + exp - needExp);
            p.sendMessage("§c[系统]§a恭喜你!你的锻造等级升到了§b§l" + pd.getLevel() + "§a级,锻造技术更上一层楼!");
        } else {
            pd.setExp(PlayerExp + exp);
        }
        needExp = ExpUtil.getNeedExp(p);
        p.sendMessage("§c[系统]§a你离下一级还需要锻造经验§e§l" + new DecimalFormat("###.00").format(pd.getExp()) + "§8/§b§l" + new DecimalFormat("###.00").format(needExp) + "点");
    }
}

