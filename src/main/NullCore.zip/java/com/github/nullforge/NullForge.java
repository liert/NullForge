package com.github.nullforge;

import com.github.nullcore.Log;
import com.github.nullcore.NullCore;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Constructor;

public class NullForge extends NullCore {
    @Override
    public void onLoad() {
    }

    @Override
    public void onEnable() {
        registerPlugin(this);
        try {
            Class<?> MainClass = Class.forName("com.github.nullforge.Main");
            // 获取带有参数的构造函数
            Constructor<?> constructor = MainClass.getConstructor(JavaPlugin.class);
            // 创建实例
            Object main = constructor.newInstance(this);
            // 调用 start 方法
            MainClass.getDeclaredMethod("start").invoke(main);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onDisable() {
        Log.info("NullForge is disabled!");
    }
}
