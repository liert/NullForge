package com.github.nullforge;

import com.github.nullforge.Commands.OnAdminCommands;
import com.github.nullforge.Commands.OnCompose;
import com.github.nullforge.Commands.OnForge;
import com.github.nullforge.Config.ConfigurationLoader;
import com.github.nullforge.Config.Settings;
import com.github.nullforge.Data.DataManagerImpl;
import com.github.nullforge.Data.MySQLManager;
import com.github.nullforge.Data.YamlManager;
import com.github.nullforge.Listeners.*;
import com.github.nullforge.PlaceHolder.NameHolder;
import com.github.nullforge.Utils.MMItemManager;
import io.lumine.xikage.mythicmobs.MythicMobs;
import java.io.File;
import java.util.Random;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public class Main {
    public static JavaPlugin instance;
    public static DataManagerImpl dataManger;
    public static Economy vault;
    public static Random rd;
    private static MythicMobs mythicMobs;
    private static MMItemManager itemManager;
    private JavaPlugin plugin;

    static {
        rd = new Random();
    }

    public Main(JavaPlugin plugin) {
        instance = plugin;
    }

    public void start() {
        EnableListener();
        mythicMobs = MythicMobs.inst();
        itemManager = new MMItemManager();
        this.setupEconomy();
        ConfigurationLoader.loadYamlConfiguration(instance, Settings.class, true);
        initDataManager();
        if (Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            new NameHolder(instance, "forge").hook();
        }
        Bukkit.getScheduler().runTaskTimerAsynchronously(instance, () -> {
            dataManger.saveDrawData();
            Bukkit.getLogger().info("[Forge]: 锻造图纸已经自动保存到数据库");
        }, 36000L, 36000L);
    }

    private void initDataManager() {
        if (Settings.I.DataManager.equals("Yaml")) {
            this.initFolder();
            dataManger = new YamlManager();
        } else if (Settings.I.DataManager.equals("MySQL")) {
            dataManger = new MySQLManager();
        }
        dataManger.getDrawData();
    }

    public void onDisable() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            dataManger.savePlayerData(p);
        }
        dataManger.saveDrawData();
    }

    private void setupEconomy() {
        RegisteredServiceProvider<Economy> economyProvider = Bukkit.getServicesManager().getRegistration(Economy.class);
        if (economyProvider != null) {
            vault = economyProvider.getProvider();
        }
    }

    private boolean DisableListener() {
        boolean DisableStatus = false;
        try {
            HandlerList.unregisterAll(instance);
            DisableStatus = true;
        } catch (Exception exception) {
            // empty catch block
        }
        return DisableStatus;
    }

    private void EnableListener() {
        instance.getCommand("dz").setExecutor(new OnForge());
        instance.getCommand("hc").setExecutor(new OnCompose());
        instance.getCommand("fadmin").setExecutor(new OnAdminCommands());
        Bukkit.getPluginManager().registerEvents(new OnPlayerBreakBlock(), instance);
        Bukkit.getPluginManager().registerEvents(new OnPlayerChat(), instance);
        Bukkit.getPluginManager().registerEvents(new OnPlayerClickInv(), instance);
        Bukkit.getPluginManager().registerEvents(new OnPlayerForgeItem(), instance);
        Bukkit.getPluginManager().registerEvents(new OnPlayerJoin(), instance);
        Bukkit.getPluginManager().registerEvents(new OnPlayerInteract(), instance);
    }

    private void initFolder() {
        try {
            File draw;
            File players;
            File dataFolder = instance.getDataFolder();
            if (!dataFolder.exists()) {
                boolean ignore = dataFolder.mkdir();
            }
            if (!(players = new File(dataFolder, "players")).exists()) {
                boolean ignore = players.mkdir();
            }
            if (!(draw = new File(dataFolder, "draw")).exists()) {
                boolean ignore = draw.mkdir();
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static MMItemManager getMMItemManager() {
        return itemManager;
    }

    public static MythicMobs getMythicMobs() {
        return mythicMobs;
    }
}

