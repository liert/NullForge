package com.github.nullforge.Data;

import com.github.nullforge.Config.Settings;
import com.github.nullforge.Utils.ItemString;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class MySQLManager
implements DataManagerImpl {
    public String ip;
    public String port;
    public String database;
    public String user;
    public String password;
    public String drawTable;
    public String playerTable;

    public MySQLManager() {
        this.ip = Settings.I.MySQL_IP;
        this.port = Settings.I.MySQL_port;
        this.database = Settings.I.MySQL_database;
        this.user = Settings.I.MySQL_user;
        this.password = Settings.I.MySQL_password;
        this.drawTable = Settings.I.DrawData_Table;
        this.playerTable = Settings.I.PlayerData_Table;
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://" + this.ip + ":" + this.port + "/" + this.database, this.user, this.password);
    }

    private void free(ResultSet rs, Statement st, Connection conn) {
        try {
            if (rs != null) {
                rs.close();
            }
            if (st != null) {
                st.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void getPlayerData(Player p) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            PlayerData pd;
            conn = this.getConnection();
            ps = conn.prepareStatement("SELECT * FROM `" + this.playerTable + "`WHERE `player` = ?");
            ps.setString(1, p.getName());
            rs = ps.executeQuery();
            if (rs.next()) {
                int level = rs.getInt("level");
                double exp = rs.getDouble("exp");
                String raw = rs.getString("learn");
                ArrayList<String> learn = new ArrayList<String>();
                if (raw != null && !raw.equals("")) {
                    if (!raw.contains(",")) {
                        learn.add(raw);
                    } else {
                        String[] raws;
                        String[] array = raws = raw.split(",");
                        int length = raws.length;
                        for (int i = 0; i < length; ++i) {
                            String s = array[i];
                            if (s == null || s.isEmpty()) continue;
                            learn.add(s);
                        }
                    }
                }
                pd = new PlayerData(level, exp, learn);
            } else {
                pd = new PlayerData(0, 0.0, new ArrayList<String>());
                ps.close();
                ps = conn.prepareStatement("INSERT IGNORE INTO `" + this.playerTable + "` VALUES(?,0,0," + null + ")");
                ps.setString(1, p.getName());
                ps.execute();
            }
            PlayerData.pMap.put(p.getName(), pd);
            this.free(rs, ps, conn);
        }
        catch (SQLException e) {
            try {
                throw new RuntimeException(e);
            }
            catch (Throwable throwable) {
                this.free(rs, ps, conn);
                throw throwable;
            }
        }
    }

    @Override
    public void savePlayerData(Player p) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        if (!PlayerData.pMap.containsKey(p.getName())) {
            return;
        }
        PlayerData pd = PlayerData.pMap.get(p.getName());
        try {
            conn = this.getConnection();
            ps = conn.prepareStatement("UPDATE `" + this.playerTable + "` SET `level`=?, `exp`=?, `learn`=? WHERE (`player`=?)");
            ps.setInt(1, pd.getLevel());
            ps.setDouble(2, pd.getExp());
            StringBuilder learn = new StringBuilder();
            if (!pd.getLearn().isEmpty()) {
                for (String s : pd.getLearn()) {
                    learn.append(s).append(",");
                }
            }
            ps.setString(3, learn.toString());
            ps.setString(4, p.getName());
            ps.execute();
            this.free(rs, ps, conn);
        }
        catch (SQLException e) {
            try {
                throw new RuntimeException(e);
            }
            catch (Throwable throwable) {
                this.free(rs, ps, conn);
                throw throwable;
            }
        }
    }

    @Override
    public void getDrawData() {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = this.getConnection();
            ps = conn.prepareStatement("SELECT * FROM `" + this.drawTable + "`");
            rs = ps.executeQuery();
            while (rs.next()) {
                String name = rs.getString("name");
                String gem = rs.getString("gem");
                String formula = rs.getString("formula");
                String result = rs.getString("result");
                int gemLevel = rs.getInt("gemlevel");
                int playerLevel = rs.getInt("playerlevel");
                String detail = rs.getString("detail");
                String attrib = rs.getString("attrib");
                ArrayList<String> list = new ArrayList<String>();
                if (!formula.contains(",")) {
                    list.add(formula);
                } else {
                    String[] raw;
                    String[] array = raw = formula.split(",");
                    int length = raw.length;
                    for (int i = 0; i < length; ++i) {
                        String s = array[i];
                        if (s.isEmpty()) continue;
                        list.add(s);
                    }
                }
                ArrayList<String> detailList = new ArrayList<String>();
                if (detail.contains("|")) {
                    String[] raw2;
                    String[] array2 = raw2 = detail.split("\\|");
                    int length2 = raw2.length;
                    for (int j = 0; j < length2; ++j) {
                        String s2 = array2[j];
                        if (s2.isEmpty()) continue;
                        detailList.add(s2);
                    }
                } else {
                    detailList.add(detail);
                }
                ArrayList<String> attribList = new ArrayList<String>();
                if (attrib.contains("|")) {
                    String[] raw2;
                    String[] array3 = raw2 = attrib.split("\\|");
                    int length3 = raw2.length;
                    for (int k = 0; k < length3; ++k) {
                        String s3 = array3[k];
                        if (s3.isEmpty()) continue;
                        attribList.add(s3);
                    }
                } else {
                    attribList.add(attrib);
                }
                DrawData dd = new DrawData(gem, list, result, gemLevel, playerLevel, detailList, attribList);
                DrawData.DrawMap.put(name, dd);
            }
            this.free(rs, ps, conn);
        }
        catch (SQLException e) {
            try {
                throw new RuntimeException(e);
            }
            catch (Throwable throwable) {
                this.free(rs, ps, conn);
                throw throwable;
            }
        }
    }

    @Override
    public void saveDrawData() {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = this.getConnection();
            for (String name : DrawData.DrawMap.keySet()) {
                StringBuilder sb;
                List<ItemStack> list;
                DrawData dd = DrawData.DrawMap.get(name);
                ps = conn.prepareStatement("SELECT * FROM `" + this.drawTable + "` WHERE `name` = '" + name + "'");
                rs = ps.executeQuery();
                if (rs.next()) {
                    ps.close();
                    ps = conn.prepareStatement("UPDATE `" + this.drawTable + "` SET `gem`=?, `formula`=?, `result`=?, `gemlevel`=?, `playerlevel`=?, `detail`=?, `attrib`=? WHERE (`name`=?)");
                    ps.setString(1, ItemString.getString(dd.getGem()));
                    list = dd.getFormula();
                    sb = new StringBuilder();
                    for (ItemStack item : list) {
                        sb.append(ItemString.getString(item)).append(",");
                    }
                    ps.setString(2, sb.toString());
                    ps.setString(3, ItemString.getString(dd.getResult()));
                    ps.setInt(4, dd.getNeedGemLevel());
                    ps.setInt(5, dd.getNeedPlayerLevel());
                    sb = new StringBuilder();
                    if (dd.getDetail().size() == 1) {
                        ps.setString(6, dd.getDetail().get(0));
                    } else {
                        for (String s : dd.getDetail()) {
                            sb.append(s).append("|");
                        }
                        ps.setString(6, sb.toString());
                    }
                    sb = new StringBuilder();
                    if (dd.getAttrib().size() == 1) {
                        ps.setString(7, dd.getAttrib().get(0));
                    } else {
                        for (String s : dd.getAttrib()) {
                            sb.append(s).append("|");
                        }
                        ps.setString(7, sb.toString());
                    }
                    ps.setString(8, name);
                    ps.execute();
                    continue;
                }
                ps.close();
                ps = conn.prepareStatement("INSERT INTO `" + this.drawTable + "` (`name`, `gem`, `formula`, `result`, `gemlevel`, `playerlevel`, `detail`, `attrib`) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                ps.setString(1, name);
                ps.setString(2, ItemString.getString(dd.getGem()));
                list = dd.getFormula();
                sb = new StringBuilder();
                for (ItemStack item : list) {
                    sb.append(ItemString.getString(item)).append(",");
                }
                ps.setString(3, sb.toString());
                ps.setString(4, ItemString.getString(dd.getResult()));
                ps.setInt(5, dd.getNeedGemLevel());
                ps.setInt(6, dd.getNeedPlayerLevel());
                sb = new StringBuilder();
                if (dd.getDetail().size() == 1) {
                    ps.setString(7, dd.getDetail().get(0));
                } else {
                    for (String s : dd.getDetail()) {
                        sb.append(s).append("|");
                    }
                    ps.setString(7, sb.toString());
                }
                sb = new StringBuilder();
                if (dd.getAttrib().size() == 1) {
                    ps.setString(8, dd.getAttrib().get(0));
                } else {
                    for (String s : dd.getAttrib()) {
                        sb.append(s).append("|");
                    }
                    ps.setString(8, sb.toString());
                }
                ps.execute();
            }
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
        finally {
            this.free(rs, ps, conn);
        }
    }

    @Override
    public void delDraw(String name) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = this.getConnection();
            ps = conn.prepareStatement("SELECT * FROM `" + this.drawTable + "` WHERE `name` = '" + name + "'");
            rs = ps.executeQuery();
            if (rs.next()) {
                ps.close();
                ps = conn.prepareStatement("DELETE FROM `" + this.drawTable + "` WHERE (`name`='" + name + "')");
                ps.execute();
            }
            this.free(rs, ps, conn);
        }
        catch (SQLException e) {
            try {
                throw new RuntimeException(e);
            }
            catch (Throwable throwable) {
                this.free(rs, ps, conn);
                throw throwable;
            }
        }
    }

    @Override
    public String getDrawName(String name) {
        return name;
    }

    static {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch (ClassNotFoundException e) {
            throw new ExceptionInInitializerError(e);
        }
    }
}

