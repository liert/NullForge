package com.github.nullforge.Data;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.github.nullforge.Main;
import com.github.nullforge.Utils.ItemString;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class YamlManager implements DataManagerImpl {
    @Override
    public void getPlayerData(Player p) {
        PlayerData pd;
        File playerDataFolder = new File(Main.instance.getDataFolder(), "players");
        File playerConfigFile = new File(playerDataFolder, p.getName() + ".yml");
        YamlConfiguration playerConfig = YamlConfiguration.loadConfiguration(playerConfigFile);
        if (playerConfigFile.exists()) {
            int level = playerConfig.getInt("level");
            double exp = playerConfig.getDouble("exp");
            List learn = playerConfig.getStringList("learn");
            pd = new PlayerData(level, exp, learn);
        } else {
            playerConfig.set("level", 0);
            playerConfig.set("exp", 0.0);
            playerConfig.set("learn", new ArrayList());
            try {
                playerConfig.save(playerConfigFile);
            }
            catch (Exception e) {
                throw new RuntimeException(e);
            }
            pd = new PlayerData(0, 0.0, new ArrayList<>());
        }
        PlayerData.pMap.put(p.getName(), pd);
    }

    @Override
    public void savePlayerData(Player p) {
        if (!PlayerData.pMap.containsKey(p.getName())) {
            return;
        }
        PlayerData pd = PlayerData.pMap.get(p.getName());
        File playerDataFolder = new File(Main.instance.getDataFolder(), "players");
        File playerConfigFile = new File(playerDataFolder, p.getName() + ".yml");
        YamlConfiguration playerConfig = YamlConfiguration.loadConfiguration(playerConfigFile);
        playerConfig.set("level", pd.getLevel());
        playerConfig.set("exp", pd.getExp());
        playerConfig.set("learn", pd.getLearn());
        try {
            playerConfig.save(playerConfigFile);
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void getDrawData() {
        File drawDataFolder = new File(Main.instance.getDataFolder(), "draw");
        File[] files = drawDataFolder.listFiles(pathname -> pathname.getName().endsWith(".yml"));
        if (files == null) {
            return;
        }
        ArrayList<String> msg = new ArrayList<>();
        Date first = new Date();
        for (File file : files) {
            YamlConfiguration drawConfig = YamlConfiguration.loadConfiguration(file);
            String name = drawConfig.getString("name");
            msg.add(name);
            String gem = drawConfig.getString("gem");
            List formula = drawConfig.getStringList("formula");
            String result = drawConfig.getString("result");
            int gemLevel = drawConfig.getInt("gemlevel");
            int playerLevel = drawConfig.getInt("playerlevel");
            List detail = drawConfig.getStringList("detail");
            List attrib = drawConfig.getStringList("attrib");
            DrawData dd = new DrawData(gem, formula, result, gemLevel, playerLevel, detail, attrib);
            DrawData.DrawMap.put(file.getName().split("\\.")[0], dd);
        }
        long diff = new Date().getTime() - first.getTime();
        Bukkit.getConsoleSender().sendMessage("§8----------------§a§lNullForge§8----------------");
        for (String s : msg) {
            Bukkit.getConsoleSender().sendMessage("§a§l>    " + s + " §a§l[已加载]");
        }
        Bukkit.getConsoleSender().sendMessage("§8-----------§a§l共加载了" + msg.size() + "个,耗时" + diff + "毫秒§8-----------");
    }

    @Override
    public void saveDrawData() {
        File drawDataFolder = new File(Main.instance.getDataFolder(), "draw");
        for (String name : DrawData.DrawMap.keySet()) {
            File drawConfigFile = new File(drawDataFolder, name + ".yml");
            YamlConfiguration drawConfig = YamlConfiguration.loadConfiguration(drawConfigFile);
            DrawData dd = DrawData.DrawMap.get(name);
            drawConfig.set("gem", ItemString.getString(dd.getGem()));
            List<ItemStack> list = dd.getFormula();
            StringBuilder sb = new StringBuilder();
            for (ItemStack item : list) {
                sb.append(ItemString.getString(item)).append(",");
            }
            drawConfig.set("formula", sb.toString());
            drawConfig.set("result", ItemString.getString(dd.getResult()));
            drawConfig.set("gemlevel", dd.getNeedGemLevel());
            drawConfig.set("playerlevel", dd.getNeedPlayerLevel());
            drawConfig.set("detail", dd.getDetail());
            drawConfig.set("attrib", dd.getAttrib());
        }
    }

    @Override
    public void delDraw(String name) {
        File drawDataFolder = new File(Main.instance.getDataFolder(), "draw");
        File drawConfigFile = new File(drawDataFolder, name + ".yml");
        if (drawConfigFile.exists()) {
            boolean bl = drawConfigFile.delete();
        }
    }

    @Override
    public String getDrawName(String name) {
        File drawDataFolder = new File(Main.instance.getDataFolder(), "draw");
        File drawConfigFile = new File(drawDataFolder, name + ".yml");
        YamlConfiguration drawConfig = YamlConfiguration.loadConfiguration(drawConfigFile);
        return drawConfig.getString("name");
    }
}

